export enum Roles {
  anonymous = 1,
  user,
  admin,
}
