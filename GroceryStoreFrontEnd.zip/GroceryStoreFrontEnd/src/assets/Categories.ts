export const categories = [
    'fruits-and-vegetables', 'veg', 'non-veg', 'dairy', 'frozen', 'drink'
]